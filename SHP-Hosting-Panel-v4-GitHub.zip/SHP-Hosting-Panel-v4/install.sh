#!/usr/bin/env bash
set -euo pipefail
command -v node >/dev/null || { echo 'Node.js 22+ is required.'; exit 1; }
node -v
npm ci
mkdir -p data/servers
if [ ! -f .env ]; then cp .env.example .env; echo 'Created .env. Edit it before starting the panel.'; fi
printf '\nSHP installed. Start with: npm start\n'
