import test from 'node:test';import assert from 'node:assert/strict';test('SHP v3 baseline',()=>assert.equal(2048,2048));
