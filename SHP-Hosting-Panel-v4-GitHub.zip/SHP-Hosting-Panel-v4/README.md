# SHP Hosting Panel v4

Modern Minecraft hosting control panel with server provisioning, Docker lifecycle controls, resource limits, redeem plans, authentication, audit/debug history and safe automatic diagnostics.

## Features

- Responsive hosting dashboard
- Minecraft server creation for Vanilla, Paper, Purpur and Fabric
- RAM, CPU and disk limits per plan
- Start / stop / restart controls
- Container logs
- Safe Debug Center with common error detection
- Daily automatic health/debug scans
- Docker integration (disabled by default)
- SQLite persistence
- Admin role and redeem-code management
- Rate limiting and Helmet security headers
- Mobile-friendly UI

## Quick start

```bash
cp .env.example .env
# edit .env
npm ci
npm start
```

Open `http://YOUR_VPS_IP:3000`.

## Docker-managed Minecraft servers

Set `ALLOW_DOCKER=true` only on a trusted VPS. The panel then needs access to the host Docker socket. This is powerful and should never be exposed without authentication/firewall protection.

```env
ALLOW_DOCKER=true
AUTO_DEBUG=true
DEBUG_INTERVAL_MS=86400000
```

The Minecraft containers use the `itzg/minecraft-server` image and store server data under `MC_DATA_ROOT`.

## Production security

- Never commit `.env`.
- Replace `JWT_SECRET` with a long random secret.
- Replace the default admin password immediately.
- Put the panel behind HTTPS/reverse proxy and a firewall.
- Restrict access to port 3000 or expose it only through your proxy.
- Docker socket access is equivalent to powerful host access; enable it only when required.

## Notes on Auto Debug

Auto Debug detects common container/runtime problems such as missing containers, stopped containers, Docker daemon failures, port conflicts, memory errors, disk-full messages, permission errors and Java version errors. It applies only conservative lifecycle fixes automatically. It does not blindly rewrite Minecraft worlds, plugins or configuration files.
